const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_PROMPT = process.env.XOSMO_SYSTEM_PROMPT ||
  "You are Xosmo, a helpful AI assistant. Have natural, friendly, concise conversations. " +
  "Reply directly to greetings. If the user says Hi, respond naturally, for example: " +
  "Hello! I'm doing well, thanks for asking. How are you? " +
  "Follow the user's language and their instructions when appropriate.";

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(GEMINI_API_KEY), model: GEMINI_MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!GEMINI_API_KEY) {
      return res.status(503).json({
        error: "Server API key is not configured. Add GEMINI_API_KEY to your host's environment variables."
      });
    }

    const messages = req.body && req.body.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Please enter a message and try again." });
    }

    // Keep only valid user/model messages and cap the conversation size.
    const safeMessages = messages.slice(-20).filter((m) =>
      m && (m.role === "user" || m.role === "model") &&
      typeof m.text === "string" && m.text.trim().length > 0
    );

    if (!safeMessages.length) {
      return res.status(400).json({ error: "No valid messages were received." });
    }

    const contents = safeMessages.map((m) => ({
      role: m.role,
      parts: [{ text: m.text.slice(0, 12000) }]
    }));

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);

    let apiResponse;
    try {
      apiResponse = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": GEMINI_API_KEY
        },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents,
          generationConfig: {
            temperature: 0.8,
            maxOutputTokens: 700
          }
        }),
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }

    const data = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const status = apiResponse.status;
      let message = "Gemini API request failed. Please try again.";
      if (status === 400) message = "Gemini rejected the request. Check the selected model and request settings.";
      else if (status === 401 || status === 403) message = "Gemini API key is invalid, restricted incorrectly, or lacks permission. Check your server environment variable and key settings.";
      else if (status === 404) message = "The selected Gemini model was not found. Set GEMINI_MODEL to a model available to your API key.";
      else if (status === 429) message = "Gemini rate limit or quota reached. Wait a little and try again.";
      else if (status >= 500) message = "Gemini is temporarily having a problem. Please try again shortly.";
      console.error("Gemini API error:", status, data?.error?.message || "No provider details");
      return res.status(502).json({ error: message });
    }

    const answer = (data.candidates || [])
      .flatMap((candidate) => candidate.content?.parts || [])
      .map((part) => part.text || "")
      .join("")
      .trim();

    if (!answer) {
      return res.status(502).json({
        error: "Gemini returned an empty answer. Try rephrasing your message."
      });
    }

    res.json({ answer });
  } catch (err) {
    if (err.name === "AbortError") {
      return res.status(504).json({ error: "The AI took too long to respond. Please try again." });
    }
    console.error("Chat server error:", err.message);
    res.status(500).json({ error: "A server error occurred. Please try again." });
  }
});

app.listen(PORT, () => {
  console.log(`Xosmo is running on port ${PORT}`);
  console.log(`Gemini key configured: ${Boolean(GEMINI_API_KEY)}`);
});
